## MyComponent6

<img src="https://cdn.nlark.com/fecodex/43e6f1ad-aa5e-4a87-bd41-185422438a83.png" style="max-width: 640px;" />
