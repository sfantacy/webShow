'use strict';

module.exports = {
  extends: require.resolve('@alipay/bigfish/eslint')
};