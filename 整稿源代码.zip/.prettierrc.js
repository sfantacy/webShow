'use strict';

module.exports = require('@alipay/bigfish/prettier');